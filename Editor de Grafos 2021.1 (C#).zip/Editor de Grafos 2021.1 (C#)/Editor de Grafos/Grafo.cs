﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;


namespace Editor_de_Grafos
{
    public class Grafo : GrafoBase, iGrafo
    {
        private bool[] visitado = new bool[999];
        private string[] cor;
        private List<int> arv;
        public int menorpeso, agmcusto = 0, menor1 = 0, menor2 = 0;

        public void Visitador()
        {
            visitado = new bool[getN()];
            cor = new string[6] { "Green", "Pink", "Yellow", "Red", "Azure", "Black" };
        }
        public int AGM(int v)
        {
            Visitador();
            arv = new List<int>(getN());            
            arv.Add(v);
            visitado[v] = true;
            getVertice(v).setCor(System.Drawing.Color.Red);
            while (Arvore_Completa())
            {
                menorpeso = 100000;
                foreach (int ve in arv)
                {
                    for (int i = 0; i < getN(); i++)
                    {
                        if (getAresta(ve, i) != null && getAresta(ve, i).getPeso() < menorpeso && !visitado[i])
                        {
                            menorpeso = getAresta(ve, i).getPeso(); menor1 = ve; menor2 = i;
                        }
                        else if (grau(i) == 0)
                        {
                            visitado[i] = true; getVertice(i).setCor(System.Drawing.Color.Green);
                        }
                    }
                }
                visitado[menor2] = true;
                arv.Add(menor2);
                getVertice(menor2).setCor(System.Drawing.Color.GreenYellow);
                agmcusto += getAresta(menor1, menor2).getPeso();
                getAresta(menor1, menor2).setCor(System.Drawing.Color.BlueViolet);
                Refresh();
            }
            return agmcusto;
        }        


        public bool Arvore()
        {
            Largura(0);
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (getAresta(i, j) != null)
                    {
                        if (getAresta(i, j).getCor() == System.Drawing.Color.Black)
                        {                            
                            return false;
                        }
                    }
                }
            }            
            return true;
        }    


        public bool Arvore_Completa()
        {
            for (int i = 0; i < visitado.Length; i++)
            {
                if (!visitado[i])
                {
                    return true;
                }
            }
            return false;
        }

        public void caminhoMinimo(int i, int j)
        {
            Console.WriteLine(Dijkstra(i, j));
        }


        public List<String> Dijkstra(int start, int finish)
        {
            var previous = new Dictionary<int, int>();
            var distances = new Dictionary<int, int>();
            var nodes = new List<Vertice>();

            List<String> path = null;

            foreach (var vertex in GrafoBase.vertices)
            {
                if (vertex.getNum() == start)
                {
                    distances[vertex.getNum()] = 0;
                }
                else
                {
                    distances[vertex.getNum()] = int.MaxValue;
                }

                nodes.Add(vertex);
            }

            while (nodes.Count != 0)
            {
                nodes.Sort((x, y) => distances[x.getNum()] - distances[y.getNum()]);

                var smallest = nodes[0];
                nodes.Remove(smallest);

                if (smallest.getNum() == finish)
                {
                    path = new List<String>();
                    while (previous.ContainsKey(smallest.getNum()))
                    {
                        path.Add(smallest.getRotulo());
                        smallest = this.getVertice(previous[smallest.getNum()]);
                    }

                    break;
                }

                if (distances[smallest.getNum()] == int.MaxValue)
                {
                    break;
                }

                foreach (var neighbor in GrafoBase.vertices)
                {
                    var alt = distances[smallest.getNum()] + neighbor.getNum();
                    if (alt < distances[neighbor.getNum()])
                    {
                        distances[neighbor.getNum()] = alt;
                        previous[neighbor.getNum()] = smallest.getNum();
                    }
                }
            }

            return path;
        }

        public void completarGrafo()
        {
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (i != j)
                    {
                        setAresta(i, j, 1);
                    }
                }
            }
            Refresh();
        }

        public bool isEuleriano()
        {
            int i;
            for (i = 0; i < getN(); i++)
            {
                if (grau(i) % 2 != 0)
                    return false;

            }
            if (getN() != 0)
                return true;
            else
                return false;
        }

        public bool isUnicursal()
        {
            int contImpar = 0;
            for (int i = 0; i < getN(); i++)
            {
                if (grau(i) % 2 != 0)
                {
                    contImpar++;
                }
            }

            if (contImpar == 2)
            {
                return true;
            }

            return false;
        }

        public void Largura(int v)
        {
            Fila f = new Fila(matAdj.GetLength(0));
            f.enfileirar(v);
            visitado[v] = true; // marca V como visitado
            while (!f.vazia())
            {
                v = f.desenfileirar(); // retira o próximo vértice da fila
                for (int i = 0; i < matAdj.GetLength(0); i++)
                {
                     
                    // se I é adjacente a V e I ainda não foi visitado
                    if (matAdj[v, i] != null && !visitado[i])
                    {
                        visitado[i] = true; // marca i como visitado
                        getAresta(v, i).setCor(Color.Blue);
                        getVertice(i).setCor(Color.Green);
                        f.enfileirar(i); // enfileira i

                    }
                }
            }
            Refresh();
        }

        
        public int Contacor()
        {
            int aux = 0;
            //for de cor
            for (int x = 0; x < cor.Length; x++)
            {
                //for pecorre cada vertice para cada cor
                for (int i = 0; i < getN(); i++)
                {
                    if (getVertice(i).getCor() == System.Drawing.Color.FromName(cor[x]))
                    {
                        aux++;
                        //encontrou uma cor ja passa para outra
                        break;
                    }
                }
            }
            return aux;
        }



        public String paresOrdenados()
        {
            string mensagem = "{";

            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (getAresta(i, j) != null)
                    {
                        mensagem += "(" + i + ", " + j + ")";
                    }
                }
            }

            mensagem += "}";
            return mensagem;
        }
        public void profundidade(int v)
        {
                visitado[v] = true; // marca V como visitado
                for (int i = 0; i < matAdj.GetLength(0); i++)
                {
                    // se I é adjacente a V e I ainda não foi visitado
                    if (matAdj[v, i] != null && !visitado[i])
                    {
                    // chamada recursiva (vá para o vértice I)
                        getAresta(v, i).setCor(System.Drawing.Color.Blue);
                        profundidade(i);
                    }
                }
            //Refresh();
        }
        

        public void LimpaGrafo()
        {
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (getAresta(i, j) != null)
                    {
                        getAresta(i, j).setCor(System.Drawing.Color.Black);
                    }
                }
            }
            Refresh();
        }

    }
}
